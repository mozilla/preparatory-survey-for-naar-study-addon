# Namespace: `browser.privacyContext`

Accesses privacy-related context / settings which can affect study/experiment behavior

## Functions

### `browser.privacyContext.permanentPrivateBrowsing( )`

**Parameters**

### `browser.privacyContext.aPrivateBrowserWindowIsOpen( )`

**Parameters**

## Events

(None)

## Properties TBD

## Data Types

(None)
