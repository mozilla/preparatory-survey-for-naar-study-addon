# Namespace: `browser.addonsMetadata`

addonsMetadata

## Functions

### `browser.addonsMetadata.getListOfInstalledAddons( )`

getListOfInstalledAddons

**Parameters**

## Events

(None)

## Properties TBD

## Data Types

(None)
